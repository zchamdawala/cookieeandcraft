( function( $ ) {
	//Load start
	$(window).load(function() {
		$( ".load-icon" ).fadeOut( "slow" );
		$( 'body' ).removeClass( 'overflowhide' );
	});
	//Load start END
} )( jQuery );
