
		<!-- pb header row end -->
	</div> <!-- header container- end -->
</div> <!-- header container-fluid end -->

<?php get_template_part( 'template-parts/sections/footer', 'widgets' ); ?>

<?php get_template_part( 'template-parts/sections/footer', 'copyright' ); ?>

<?php get_template_part( 'template-parts/sections/footer', 'backtotop' ); ?>

<?php wp_footer(); ?>
</body>
</html>