<div class="post-contents">

	<div class="post-title">
		<h1>
			<?php
			_e( 'Oops! That page can&rsquo;t be found.', 'di-blog' );
			?>
		</h1>
	</div>

	<div class="post-excepr-content entry-content">
		<p>
			<?php
			_e( 'It looks like nothing was found at this location. Maybe try a search?', 'di-blog' );
			?>
		</p>
		<?php
		get_search_form();
		?>
	</div>

</div>