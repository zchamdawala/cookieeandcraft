<?php do_action( 'di_blog_hdrimg_file' );
