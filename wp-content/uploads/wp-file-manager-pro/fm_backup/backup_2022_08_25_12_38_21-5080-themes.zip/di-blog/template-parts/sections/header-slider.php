<?php
do_action( 'di_blog_header_slider_file' );
