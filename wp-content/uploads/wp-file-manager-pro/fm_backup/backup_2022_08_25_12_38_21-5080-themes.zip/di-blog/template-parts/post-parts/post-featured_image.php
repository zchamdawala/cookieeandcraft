<?php di_blog_post_thumbnail(); ?>
