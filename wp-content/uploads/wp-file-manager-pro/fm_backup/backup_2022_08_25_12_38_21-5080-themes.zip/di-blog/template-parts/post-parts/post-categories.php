<div class="post-category">
	<p>
		<?php the_category( ', ' ); ?>
	</p>
</div>
