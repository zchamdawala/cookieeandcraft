<div class="post-title">
	<h1 class="entry-title" itemprop="headline">
		<?php the_title(); ?>
	</h1>
</div>