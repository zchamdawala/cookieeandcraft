<div class="post-contents">

	<div class="post-title">
		<h1>
			<?php
			_e( 'Nothing Found', 'di-blog' );
			?>
		</h1>
	</div>

	<div class="post-excepr-content entry-content">
		<p>
			<?php
			_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'di-blog' );
			?>
		</p>
		<?php
		get_search_form();
		?>
	</div>

</div>