<?php get_header(); ?>
<div class="col-md-8" >
	<?php
		get_template_part( 'template-parts/content', '404' );
	?>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>