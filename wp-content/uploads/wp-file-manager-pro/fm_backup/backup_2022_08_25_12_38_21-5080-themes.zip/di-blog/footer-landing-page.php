<?php get_template_part( 'template-parts/sections/footer', 'backtotop' ); ?>

<?php wp_footer(); ?>
</body>
</html>